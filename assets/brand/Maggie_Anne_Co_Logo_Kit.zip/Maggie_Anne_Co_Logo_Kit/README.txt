MAGGIE ANNE CO. — STARTER LOGO KIT

Included:
- 01-primary-horizontal.svg — main horizontal logo
- 02-stacked-logo.svg — centered/compact version
- 03-circular-badge.svg — social avatar, stickers, stamps
- 04-ma-monogram.svg — small icon or favicon starting point
- 05-mountain-sunrise-icon.svg — standalone brand symbol

All files are editable vector SVGs and use the established brand colors:
Deep Plum #503845
Dusty Rose #BD8D95
Warm Cream #E3D4CE
Muted Mauve #856476

These are clean starter vector interpretations of the approved mountain/sunrise direction.
The typography uses common system font families (Georgia and Arial) so it remains portable.
For a final production identity, choose/licence the exact display and script fonts and
review spacing, kerning, and small-size legibility before commercial printing.
